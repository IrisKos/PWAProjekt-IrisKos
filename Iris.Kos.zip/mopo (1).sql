-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2021 at 05:28 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mopo`
--
CREATE DATABASE IF NOT EXISTS `mopo` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `mopo`;

-- --------------------------------------------------------

--
-- Table structure for table `clanci`
--

CREATE TABLE `clanci` (
  `id` int(11) NOT NULL,
  `datum` varchar(32) CHARACTER SET utf8 COLLATE utf8_croatian_ci NOT NULL,
  `naslov` varchar(64) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `kratki_sadrzaj` text CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `sadrzaj` text CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `kategorija` varchar(64) NOT NULL,
  `slika` varchar(64) CHARACTER SET latin2 COLLATE latin2_croatian_ci NOT NULL,
  `arhiva` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clanci`
--

INSERT INTO `clanci` (`id`, `datum`, `naslov`, `kratki_sadrzaj`, `sadrzaj`, `kategorija`, `slika`, `arhiva`) VALUES
(4, '10.06.2021.', 'Frauen planschen in fremdem Pool ? und rasten völlig aus', 'Ein Streit um einen Kinderpool ist in Bayern eskaliert. Nach Angaben der Polizei von Sonntag...', 'Ein Streit um einen Kinderpool ist in Bayern eskaliert. Nach Angaben der Polizei von Sonntag haben es sich eine 19-Jährige und ihre 30-jährige Freundin am Samstagabend in einem Kinderpool in Lichtenfels bequem gemacht. Das Problem war nur, dass dieser ihnen nicht gehörte.\r\n\r\nAls sie von der Pool-Besitzerin darauf angesprochen wurden, schlug die 30-Jährige dieser ins Gesicht. Bis die Polizei vor Ort war, zerstörten die Freundinnen den Pool so sehr, dass er nicht mehr zu gebrauchen war.', 'Vijesti', 'thirdpic.jpg', 0),
(5, '10.06.2021.', 'Viele Menschen versammeln sich an der Elbe und in Parks', 'Viele Menschen haben sich am Samstagabend wieder in Hamburger und Kieler Parks versamme...', 'Viele Menschen haben sich am Samstagabend wieder in Hamburger und Kieler Parks versammelt. ?Es gab hier und dort größere Ansammlungen, aber es war nicht problematisch?, sagte ein Sprecher der Hamburger Polizei am Sonntagmorgen.\r\n\r\nSo hätten sich am Falkensteiner Ufer in Blankenese sowie in den angrenzenden Parks etwa 400 bis 500 Jugendliche aufgehalten. Auch im Stadtpark seien insgesamt 1500 bis 1800 Menschen gewesen, darunter vermehrt jugendliche Gruppen.\r\n\r\nWie die Polizei mitteilte, habe es Ansprachen gegeben, teilweise auch Platzverweise, mehrere Strafanzeigen, eine vorläufige Festnahme und ruhestörenden Lärm. Allerdings sei die Lage nicht mit den letzten Tagen vergleichbar gewesen, es gab keine größeren Einsätze. Im Schanzenviertel herrschte zudem weiterhin Alkoholverbot.', 'Vijesti', 'forthpic.jpg', 0),
(6, '10.06.2021.', 'AstraZeneca-Impfaktionen: Grosser Andrang im Norden', 'Aktuelle Inzidenzverte, Fallzahlen, Corona-Regeln und Lockerun...', 'Aktuelle Inzidenzverte, Fallzahlen, Corona-Regeln und Lockerungen: In unserem Newsticker halten wir Sie uber die aktuelle Corona-Entvicklung in Hamburg, Schlesig-Holstein, Niedersachsen und Mecklenburg-Vorpommern.', 'Vijesti', 'fifthpic.jpg', 0),
(7, '10.06.2021.', 'Kaderplanung: Der HSV passt sich immer mehr der 2. Liga an', 'Was ist der HSV? Ist es immer noch ein grosser Verein, der eigentlich in die Bundesliga gehr...', 'Was ist der HSV? Ist es immer noch ein groer Verein, der eigentlich in die Bundesliga geort? Oder ist es mittlereile nur noch ein ganz normaler Zeitligist, der da spielt, o er auch hingehrt? Die Ergebnisse der letzten drei Jahre sprechen fur Letzteres. Und auch beim Blick auf den aktuellen Kader wird deutlich, dass sich die Hamburger immer mehr der Zweiten Liga anpassen.', 'Sport', 'sixpick.jpg', 0),
(8, '10.06.2021.', 'Uber 100 Mio. Ablse? Enttuschter Coman will Bayern verlassen', 'Die Karriere von Bayern-Star Kingsley Coman konnte nicht besser lau...', 'Die Karriere von Bayern-Star Kingsley Coman konnte nicht besser lau...Die Karriere von Bayern-Star Kingsley Coman konnte nicht besser lau...Die Karriere von Bayern-Star Kingsley Coman konnte nicht besser lau...Die Karriere von Bayern-Star Kingsley Coman konnte nicht besser lau...', 'Sport', 'seventhpic.jpg', 0),
(9, '10.06.2021.', 'Bayern-Boss Hainer: Keine grossen Transfers mehr!', 'Der FC Bayern plant nach der Verpflichtung von Dayot Upamecano keine kostspieligen Neuzugage mehr fur die neue Sais...', 'Der FC Bayern plant nach der Verpflichtung von Dayot Upamecano keine kostspieligen Neuzugänge mehr für die neue Saison.\r\n\r\n?Die Leute sollen die Auswirkungen von Corona bloß nicht unterschätzen, auch wenn wir vergleichsweise bisher wirtschaftlich gut über die Runden gekommen sind, wird es bei uns erhebliche Schleifspuren geben. Bis auf Dayot Upamecano sind bei uns in diesem Sommer keinen großen Transfers mehr möglich?, sagte Präsident Herbert Hainer in einem am Freitag veröffentlichten Interview auf der Homepage des deutschen Rekordmeisters.', 'Sport', 'eightpic.jpg', 0),
(11, '13.06.2021.', 'In 50 Metern Hohe', 'In 50 Metern HoheIn 50 Metern HoheIn 50 Metern Hohe', 'In 50 Metern HoheIn 50 Metern HoheIn 50 Metern HoheIn 50 Metern HoheIn 50 Metern Hohe', 'Sport', 'firstpic.jpg', 1),
(12, '13.06.2021.', 'In 50 Metern Hohe', 'In 50 Metern HoheIn 50 Metern HoheIn 50 Metern Hohe', 'In 50 Metern HoheIn 50 Metern HoheIn 50 Metern HoheIn 50 Metern HoheIn 50 Metern Hohe', 'Sport', 'firstpic.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `id` int(11) NOT NULL,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_croatian_ci NOT NULL,
  `ime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_croatian_ci NOT NULL,
  `prezime` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_croatian_ci NOT NULL,
  `lozinka` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_croatian_ci NOT NULL,
  `razina` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_croatian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id`, `username`, `ime`, `prezime`, `lozinka`, `razina`) VALUES
(1, 'Iris', 'Iris', 'Iris', '$2y$10$Vk.L5HPAUX8e2SIZVKMPUeeoGAd2kKDVYHwn5EYvuP90uyjSYH.ZO', 'administrator');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clanci`
--
ALTER TABLE `clanci`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clanci`
--
ALTER TABLE `clanci`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
