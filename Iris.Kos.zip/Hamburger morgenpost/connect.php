<?php
$dbc=mysqli_connect('localhost:3306','root','','mopo') or 
    die('Error u spajanju!'.mysqli_connect_error());

?>