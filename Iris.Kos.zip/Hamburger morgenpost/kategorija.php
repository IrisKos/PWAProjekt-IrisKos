<?php
    include 'connect.php';
    define('UPLPATH', 'img/');
   



?>



<!DOCTYPE html>
<html>

<head>
    <title> <?php
             $kategorija=$_GET['kategorija'];
             echo ucfirst($kategorija);?>
             </title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>


<body>
    	<header>
		<div class="empty">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-12">
					.
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-lg-2 col-md-12 col-12">
					<img src="images/logo.png" alt="logo" class="logo" />
				</div>
				<div class="col-lg-10 col-md-12 col-12">
					<div class="container">
					 <nav>
						 <ul>
							 <div class="row">
								 <li class="col-lg-3 col-md-12 col-12"><a href="index.php"> HOME </a></li>
								 <li class="col-lg-3 col-md-12 col-12"><a href="kategorija.php?kategorija=vijesti"> VIJESTI </a></li>
								 <li class="col-lg-3 col-md-12 col-12"><a href="kategorija.php?kategorija=sport"> SPORT </a></li>
								 <li class="col-lg-3 col-md-12 col-12"><a href="administracija.php"> ADMINISTRACIJA </a></li>
							</div>
						 </ul>
					 </nav>
				</div>
				</div>

			</div>
		</div>
	</header>
    <?php
    $kategorija=$_GET['kategorija'];
    if($kategorija=='sport'){
    echo "<div class='drh'>
            <div class='wrapper'>
            <h2>SPORT</h2>";}
    else{
        echo "<div class='vjh'>
        <div class='wrapper'>
            <h2>VIJESTI</h2>";
        
    }
    ?>

        </div>
    </div>
    <div class="wrapper-k">
        <br>
            <section>
            <?php
             $kategorija=$_GET['kategorija'];
            $query = "SELECT * FROM clanci WHERE arhiva=0 AND kategorija='$kategorija'";
            $result = mysqli_query($dbc, $query);
            echo "<div class='container-fluid'>
            <div class='row'>";
            while($row = mysqli_fetch_array($result)) {
                    echo '<div class="col-lg-4 col-sm-12">';
                    echo '<a id="noh" href="clanak.php?id='.$row['id'].'">';
                    
                    echo '<img width="200" height="150" src="'.UPLPATH.$row['slika'].'">';
                    echo '<h6 id="nas";">'.$row['naslov'].'</h6>';
                    echo '<p id="nasi">'.$row['kratki_sadrzaj'].'</p></a>';                       
                    echo "</div>"; 
            }
           echo "</div>
            </div>";
            ?>  

            </section>
    </div>



    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-12">
                    <p>Copyright 2019 Morgenpost Verlag GmbH</p>
                </div>
            </div>
        </div>
    </footer>


</body>



</html>