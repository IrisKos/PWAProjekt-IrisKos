﻿<?php 

    include 'connect.php';
    define('UPLPATH', 'img/');

    $id=$_GET["id"];
    if(isset($id)){

    $query = "SELECT naslov,sadrzaj,kratki_sadrzaj,slika,kategorija FROM clanci WHERE arhiva=0 AND id=$id";
    $result = mysqli_query($dbc, $query);
    $row=mysqli_fetch_array($result);
    $naslov=$row['naslov'];
    $sadrzaj=$row['sadrzaj'];
    $ksad=$row['kratki_sadrzaj']; 
    $slika=UPLPATH.$row['slika'];
    $kategorija=$row['kategorija'];



    




echo "<!DOCTYPE html>
<html>

<head>
    <title>Članak</title>
    <link rel='stylesheet' type='text/css' href='style.css'>
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css'
        integrity='sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh' crossorigin='anonymous'>
</head>";

echo '
<body>
     	<header>
		<div class="empty">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-12">
					.
				</div>
			</div>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-lg-2 col-md-12 col-12">
					<img src="images/logo.png" alt="logo" class="logo" />
				</div>
				<div class="col-lg-10 col-md-12 col-12">
					<div class="container">
					 <nav>
						 <ul>
							 <div class="row">
								 <li class="col-lg-3 col-md-12 col-12"><a href="index.php"> HOME </a></li>
								 <li class="col-lg-3 col-md-12 col-12"><a href="kategorija.php?kategorija=vijesti"> VIJESTI </a></li>
								 <li class="col-lg-3 col-md-12 col-12"><a href="kategorija.php?kategorija=sport"> SPORT </a></li>
								 <li class="col-lg-3 col-md-12 col-12"><a href="administracija.php"> ADMINISTRACIJA </a></li>
							</div>
						 </ul>
					 </nav>
				</div>
				</div>

			</div>
		</div>
	</header>
    ';
  
    echo "
    <div class='clanak-bg'>   
    
    <div class='wrapper-clanak'>
        <h2 'dat'>$naslov</h2>
        <hr>
        <h6 id='dati'>" ; echo date('l, F jS, Y'); echo"</h6>
            <section>
                <img src='$slika'>
                <br>
                <br>
                <h5>$ksad</h5>
                <br>
                <p>$sadrzaj</p>



            </section>
    </div>
    </div>
    </div>

    <footer>
        <div class='container'>
            <div class='row'>
                <div class='col-lg-12 col-12'>
                    <p>Copyright 2019 Morgenpost Verlag GmbH</p>
                </div>
            </div>
        </div>
    </footer>


</body>



</html>";


    }
    else{

        echo "Bad URL";
    }
mysqli_close($dbc);





?>